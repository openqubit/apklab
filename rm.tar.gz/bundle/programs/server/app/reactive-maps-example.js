(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// reactive-maps-example.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Friends = new Meteor.Collection('friends');                            // 1
Requests = new Meteor.Collection('requests');                          // 2
                                                                       //
Meteor.startup(function () {                                           // 4
                                                                       //
  if (Meteor.isClient) {                                               // 6
    navigator.contacts.find();                                         // 7
    console.log(navigator.contacts.find());                            // 8
  }                                                                    //
});                                                                    //
                                                                       //
if (Meteor.isCordova) {                                                // 12
  var options = new ContactFindOptions();                              // 13
  options.filter = "";                                                 // 14
  options.multiple = true;                                             // 15
  var fields = ["displayName", "name"];                                // 16
  vm.contacts = navigator.contacts.find(fields, onSuccess, onError, options);
                                                                       //
  function onSuccess(contacts) {                                       // 19
    console.log(contacts.length + 'contacts');                         // 20
    for (var i = 0; i < contacts.length; i++) {                        // 21
      console.log("Display Name = " + contacts[i].displayName);        // 22
    }                                                                  //
  }                                                                    //
                                                                       //
  function onError(contactError) {                                     // 26
    console.log('onError!');                                           // 27
  }                                                                    //
}                                                                      //
                                                                       //
if (Meteor.isClient) {                                                 // 31
  /**                                                                  //
  Router.route('/',function(){                                         //
      console.log('landing page is loaded');                           //
      latLng = Geolocation.latLng();                                   //
      var userid = Meteor.userId();                                    //
      window.location = '/' + latLng.lat + '/' + latLng.lng + '/' + userid;
  });                                                                  //
  */                                                                   //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 42
                                                                       //
  Meteor.methods({                                                     // 44
    'allfb': function () {                                             // 45
      /**                                                              //
      this.unblock();                                                  //
      var user = Meteor.user();                                        //
      if (user.hasOwnProperty('services') && user.services.hasOwnProperty('facebook')  ) {
      var result = Meteor.http.get('https://graph.facebook.com/v2.4/' + user.services.facebook.id + '?access_token=' + user.services.facebook.accessToken + '&fields=first_name, last_name, birthday, email, gender, location, link, friends');
       console.log(result.data.first_name);                            //
      console.log(result.data.last_name);                              //
      console.log(result.data.birthday);                               //
      console.log(result.data.email);                                  //
      console.log(result.data.gender);                                 //
      console.log(result.data.location);                               //
      console.log(result.data.link);                                   //
      console.log(result.data.friends);                                //
      }                                                                //
      }                                                                //
      */                                                               //
    }                                                                  //
  });                                                                  //
                                                                       //
  Meteor.publish("friends", function () {                              // 67
    return Friends.find();                                             // 68
  });                                                                  //
  Meteor.publish("requests", function () {                             // 70
    return Requests.find();                                            // 71
  });                                                                  //
  Meteor.publish("users", function () {                                // 73
    return Meteor.users.find();                                        // 74
  });                                                                  //
  Meteor.startup(function () {                                         // 76
    if (Friends.find().count() === 0) {                                // 77
      Friends.insert({ userid: 0, friendid: 0 });                      // 78
    }                                                                  //
    if (Requests.find().count() === 0) {                               // 80
      Requests.insert({ userid: 0, friendid: 0 });                     // 81
    }                                                                  //
    Accounts.loginServiceConfiguration.remove({                        // 83
      service: "facebook"                                              // 84
    });                                                                //
    Accounts.loginServiceConfiguration.insert({                        // 86
      service: "facebook",                                             // 87
      appId: "1369489926397936",                                       // 88
      secret: "46de773cd67bc126265a82c92486b99b"                       // 89
    });                                                                //
                                                                       //
    // first, remove configuration entry in case service is already configured
    Accounts.loginServiceConfiguration.remove({                        // 93
      service: "twitter"                                               // 94
    });                                                                //
    Accounts.loginServiceConfiguration.insert({                        // 96
      service: "twitter",                                              // 97
      consumerKey: "IYg2CZyDusOuxz3OUr6c3Ag0Y",                        // 98
      secret: "euWmLsgkf6czv9ih8mK50EHUlO5S8NbekDayd0dON2kY24RElC"     // 99
    });                                                                //
                                                                       //
    // first, remove configuration entry in case service is already configured
    Accounts.loginServiceConfiguration.remove({                        // 103
      service: "google"                                                // 104
    });                                                                //
    Accounts.loginServiceConfiguration.insert({                        // 106
      service: "google",                                               // 107
      clientId: "291832390597-iblfe4fqvmcl1qbsfttj7m04093848h1.apps.googleusercontent.com",
      secret: "gDZUPq6XfLMC-RqjkbOT1jov"                               // 109
    });                                                                //
  });                                                                  //
}                                                                      //
if (Meteor.isClient) {                                                 // 113
                                                                       //
  Meteor.subscribe("users");                                           // 115
  Meteor.subscribe("friends");                                         // 116
  Meteor.subscribe("requests");                                        // 117
  Template.lenav.events({                                              // 118
    'click .kr': function (event, template) {                          // 119
      event.preventDefault();                                          // 120
      console.log('lenav');                                            // 121
    }                                                                  //
  });                                                                  //
  Template.au.onRendered(function () {                                 // 124
    /**                                                                //
    var ayudaContactos = {                                             //
    if(Meteor.isCordova){                                              //
    function onSuccess(contacts){                                      //
     console.log(contacts);                                            //
     contacts = _.sortBy(contacts, function(o) { return o.name.givenName; })
     Session.set("contactos",contacts);                                //
    };                                                                 //
    function onError(contactError){                                    //
     Session.set("contactos","");                                      //
    };                                                                 //
    var options = new ContactFindOptions();                            //
    options.multiple = true;                                           //
    var fields       = ["displayName", "name"];                        //
    var contactos = navigator.contacts.find(fields, onSuccess, onError, options);
    }else{                                                             //
    Session.set("contactos", ayudaContactos);                          //
    }                                                                  //
    }                                                                  //
    */                                                                 //
    if (Meteor.isCordova) {                                            // 145
      TelephoneNumber.get(function (result) {                          // 146
        alert('Phone number: ' + result.line1Number);                  // 147
      }, function () {                                                 //
        alert('Error. Do the phone have this feature? (Settings > About Phone > SIM > Number)');
      });                                                              //
    }                                                                  //
  });                                                                  //
  Template.logout.events({                                             // 153
    'click #logout': function () {                                     // 154
      /*                                                               //
      Meteor.logout();                                                 //
      document.location.reload(true);                                  //
      */                                                               //
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.logout.onCreated(function () {});                           // 163
  Template.au.helpers({                                                // 166
    contactos: function () {                                           // 167
      return Session.get("contactos");                                 // 168
    },                                                                 //
    tituloNav: "Invitar amigos"                                        // 170
  });                                                                  //
                                                                       //
  Meteor.methods({                                                     // 173
    'removeFriend': function (selector) {                              // 174
      Friends.remove(selector);                                        // 175
    },                                                                 //
    'removeFriendCompletely': function (selector2) {                   // 177
      Friends.remove(selector2);                                       // 178
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=reactive-maps-example.js.map
