(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;

/* Package-scope variables */
var FriendIDs;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/hpx7_fb-friends/packages/hpx7_fb-friends.js                                                       //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
(function () {                                                                                                // 1
                                                                                                              // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////   // 3
//                                                                                                       //   // 4
// packages/hpx7:fb-friends/fb-friends.js                                                                //   // 5
//                                                                                                       //   // 6
///////////////////////////////////////////////////////////////////////////////////////////////////////////   // 7
                                                                                                         //   // 8
FriendIDs = function (userId) {                                                                          // 1
  var user = Meteor.users.findOne(userId);                                                               // 2
  if (!user || !user.services.facebook) return [];                                                       // 3
  return _.pluck(HTTP.get('https://graph.facebook.com/v2.2/' + user.services.facebook.id + '/friends', { // 4
    params: {access_token: user.services.facebook.accessToken, limit: 10000}                             // 5
  }).data.data, 'id').concat(user.services.facebook.id);                                                 // 6
};                                                                                                       // 7
                                                                                                         // 8
///////////////////////////////////////////////////////////////////////////////////////////////////////////   // 17
                                                                                                              // 18
}).call(this);                                                                                                // 19
                                                                                                              // 20
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['hpx7:fb-friends'] = {
  FriendIDs: FriendIDs
};

})();

//# sourceMappingURL=hpx7_fb-friends.js.map
