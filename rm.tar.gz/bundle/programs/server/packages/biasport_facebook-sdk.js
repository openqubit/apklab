(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Spacebars = Package.spacebars.Spacebars;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['biasport:facebook-sdk'] = {};

})();

//# sourceMappingURL=biasport_facebook-sdk.js.map
