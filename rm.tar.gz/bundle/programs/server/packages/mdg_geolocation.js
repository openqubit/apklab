(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ReactiveVar = Package['reactive-var'].ReactiveVar;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mdg:geolocation'] = {};

})();

//# sourceMappingURL=mdg_geolocation.js.map
